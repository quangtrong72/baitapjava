package BAI62;

public interface GeometricObject {
    double getArea();
    double getPerimeter();
}

