package BAI46;

public class Mammal {
    public Mammal(String name) {
        super();
    }

    
    @Override
    public String toString() {
        return "Mammal[" + super.toString() + "]";
    }
}

