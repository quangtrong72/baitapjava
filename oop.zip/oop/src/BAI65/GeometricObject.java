package BAI65;

public interface GeometricObject {
    double getPerimeter();
    double getArea();
}
