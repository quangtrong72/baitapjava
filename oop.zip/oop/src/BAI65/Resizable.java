package BAI65;

public interface Resizable {
    void resize(int percent);
}

