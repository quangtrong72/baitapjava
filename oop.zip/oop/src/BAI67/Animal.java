package BAI67;

abstract public class Animal {
    abstract public void greeting();
}